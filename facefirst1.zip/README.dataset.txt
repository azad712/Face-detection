# facefirst > 2023-11-04 7:16pm
https://universe.roboflow.com/azad-jkgqg/facefirst-gkkwd

Provided by a Roboflow user
License: CC BY 4.0

